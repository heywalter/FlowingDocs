# MySQL DITA 写作练习

这些数据库场景仅用于写作练习，不是完整的生产操作说明。

三个主题文件由两份 map 共用。修改 start-service.dita 后，两本说明书都使用修改后的步骤。

1. 在 Oxygen 的 DITA Maps Manager 中打开 quickstart.ditamap。
2. 打开 start-service.dita，在 Author 视图编辑一个步骤，运行校验并保存。
3. 打开 guide.ditamap，查看同一主题，然后用 HTML5 发布场景生成说明书。

也可以安装 DITA-OT，并将其 bin 目录加入 PATH，在解压目录执行：

```sh
dita --input=quickstart.ditamap --format=html5 --output=out/quickstart
dita --input=guide.ditamap --format=html5 --output=out/guide
```

命令说明：https://www.dita-ot.org/dev/topics/build-using-dita-command
