# MySQL DITA writing exercise

These database scenarios are writing exercises, not complete production procedures.

Two maps share three topic files. Edit start-service.dita once to use the updated steps in both guides.

1. Open quickstart.ditamap in Oxygen’s DITA Maps Manager.
2. Open start-service.dita, edit a step in Author mode, validate, and save.
3. Open guide.ditamap, inspect the same topic, and publish using an HTML5 transformation scenario.

Alternatively, install DITA-OT, add its bin directory to PATH, and run these commands from the extracted directory:

```sh
dita --input=quickstart.ditamap --format=html5 --output=out/quickstart
dita --input=guide.ditamap --format=html5 --output=out/guide
```

Command reference: https://www.dita-ot.org/dev/topics/build-using-dita-command
